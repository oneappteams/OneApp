package mind.com.oneapp.Framework;

/**
 * Created by Kiran on 01-02-2016.
 */
public interface ActivityCommunicator{
    public void passDataToActivity(String tabTitle, String url);
}
